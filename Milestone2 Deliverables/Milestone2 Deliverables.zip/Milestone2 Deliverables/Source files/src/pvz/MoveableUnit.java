package pvz;
/**
 * @author  Arzaan Irani
 * 100826631
 */
public interface MoveableUnit {	
	public void move(Field.Direction dir);
}
